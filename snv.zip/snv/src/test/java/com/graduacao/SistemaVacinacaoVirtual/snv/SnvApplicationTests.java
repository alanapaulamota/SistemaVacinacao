package com.graduacao.SistemaVacinacaoVirtual.snv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SnvApplicationTests {

	@Test
	void contextLoads() {
	}

}
